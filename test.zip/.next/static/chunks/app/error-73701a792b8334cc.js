(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[601],{4950:function(r,e,n){Promise.resolve().then(n.bind(n,3707))},3707:function(r,e,n){"use strict";n.r(e),n.d(e,{default:function(){return Errer}});var t=n(7437);function Errer(r){let{error:e,reset:n}=r;return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("h4",{children:"에러남"}),(0,t.jsx)("button",{onClick:()=>{n()},children:"다시 로딩"})]})}},622:function(r,e,n){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=n(2265),o=Symbol.for("react.element"),u=Symbol.for("react.fragment"),s=Object.prototype.hasOwnProperty,f=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,c={key:!0,ref:!0,__self:!0,__source:!0};function q(r,e,n){var t,u={},i=null,_=null;for(t in void 0!==n&&(i=""+n),void 0!==e.key&&(i=""+e.key),void 0!==e.ref&&(_=e.ref),e)s.call(e,t)&&!c.hasOwnProperty(t)&&(u[t]=e[t]);if(r&&r.defaultProps)for(t in e=r.defaultProps)void 0===u[t]&&(u[t]=e[t]);return{$$typeof:o,type:r,key:i,ref:_,props:u,_owner:f.current}}e.Fragment=u,e.jsx=q,e.jsxs=q},7437:function(r,e,n){"use strict";r.exports=n(622)}},function(r){r.O(0,[971,472,560],function(){return r(r.s=4950)}),_N_E=r.O()}]);