
export default function Errer({error, reset}){

    return(
        <>
        <h4>404 없는 페이지 입니다</h4>
        
        </>
    )

}