// import { db } from '@/util/database'; // 데이터베이스에서 데이터를 가져오는 함수를 가져옵니다.
// import Link from "next/link";
// const { getServerSideProps } = require('next');






export default function Home() {
  return (
    <div>
      <h3 className="title">Toy Board</h3>
      <h4 className="title-sub">by dev zinkki</h4>
    </div>
  );
}